
== = ,
.
double i;